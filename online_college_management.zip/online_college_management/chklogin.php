<?php
ob_start();
session_start();
include("db/connect.php"); // Ensure this file uses mysqli_connect()

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $uname = mysqli_real_escape_string($conn, $_POST['username']);
    $pword = mysqli_real_escape_string($conn, $_POST['password']);

    // Use prepared statements to prevent SQL injection
    $query = "SELECT username, password FROM login WHERE username = ? AND password = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ss", $uname, $pword);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $count_users = mysqli_num_rows($result);

    if ($count_users == 1) {
        $_SESSION['username'] = $uname;
        echo "<script>alert('Login Successful.');</script>";
        header("Location: student/index.php");
        exit();
    } else {
        echo "<script>alert('Wrong username or password entered.');</script>";
    }

    mysqli_stmt_close($stmt);
}

ob_flush();
?>
