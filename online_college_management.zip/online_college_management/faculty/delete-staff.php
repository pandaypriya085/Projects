<?php
include("../db/connect.php");

$id = $_GET['id'];

// Use prepared statement for security
$query = $conn->prepare("DELETE FROM staff_details WHERE id = ?");
$query->bind_param("i", $id); // "i" stands for integer type
$query_run = $query->execute();

if ($query_run) {
	$success_msg = "Data Deleted Successfully!";
	echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('$success_msg')
        window.location.href='show-staff.php';
        </SCRIPT>");
} else {
	echo "Error deleting record.";
}

$query->close();
$conn->close();
?>