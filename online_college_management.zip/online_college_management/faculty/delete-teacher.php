<?php
include("../db/connect.php");

// ✅ Securely fetch the 'id' parameter
$id = isset($_GET['id']) ? mysqli_real_escape_string($conn, $_GET['id']) : '';

if (!$id) {
    die("Invalid ID");
}

// ✅ Use MySQLi query
$query = mysqli_query($conn, "DELETE FROM teacher_details WHERE id='$id'");

if ($query) {
    $success_msg = "Data Deleted Successfully!";
    echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('$success_msg');
        window.location.href='show-data.php';
    </SCRIPT>");
} else {
    echo "Error: " . mysqli_error($conn);
}

// ✅ Close the connection
mysqli_close($conn);
?>