<?php
if (isset($_POST['submit']))  // ⚠️ Semicolon (;) hata diya
{
    include('../db/connect.php');

    // Data ko sanitize karna zaroori hai
    $staff_id = mysqli_real_escape_string($conn, $_POST['staff_id']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $dob = mysqli_real_escape_string($conn, $_POST['dob']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $join_date = mysqli_real_escape_string($conn, $_POST['join_date']);
    $qualification = mysqli_real_escape_string($conn, $_POST['qualification']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    $district = mysqli_real_escape_string($conn, $_POST['district']);
    $state = mysqli_real_escape_string($conn, $_POST['state']);
    $mobile = mysqli_real_escape_string($conn, $_POST['mobile']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $department = mysqli_real_escape_string($conn, $_POST['department']);
    $salary = mysqli_real_escape_string($conn, $_POST['salary']);

    // SQL Query
    $query = "INSERT INTO staff_details (staff_id, name, dob, gender, join_date, qualification, address, city, district, state, mobile, email, department, salary) 
              VALUES ('$staff_id', '$name', '$dob', '$gender', '$join_date', '$qualification', '$address', '$city', '$district', '$state', '$mobile', '$email', '$department', '$salary')";

    // Query run karne ke liye mysqli_query ka sahi tarika
    $query_run = mysqli_query($conn, $query);

    if ($query_run) {
        $success_msg = "Staff Details has been Submitted Successfully!";
        echo ("<SCRIPT LANGUAGE='JavaScript'>
                window.alert('$success_msg');
                window.location.href='show-staff.php';
               </SCRIPT>");
    } else {
        echo "Error: " . mysqli_error($conn);  // ⚠️ Debugging ke liye error show karein
    }
}
?>
