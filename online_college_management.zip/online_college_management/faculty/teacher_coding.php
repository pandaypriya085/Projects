<?php
if (isset($_POST['submit'])) {
    include('../db/connect.php');

    // Secure inputs to prevent SQL injection
    $teacher_id   = mysqli_real_escape_string($conn, $_POST['teacher_id']);
    $name         = mysqli_real_escape_string($conn, $_POST['name']);
    $dob          = mysqli_real_escape_string($conn, $_POST['dob']);
    $gender       = mysqli_real_escape_string($conn, $_POST['gender']);
    $join_date    = mysqli_real_escape_string($conn, $_POST['join_date']);
    $qualification= mysqli_real_escape_string($conn, $_POST['qualification']);
    $address      = mysqli_real_escape_string($conn, $_POST['address']);
    $city         = mysqli_real_escape_string($conn, $_POST['city']);
    $district     = mysqli_real_escape_string($conn, $_POST['district']);
    $state        = mysqli_real_escape_string($conn, $_POST['state']);
    $mobile       = mysqli_real_escape_string($conn, $_POST['mobile']);
    $email        = mysqli_real_escape_string($conn, $_POST['email']);

    // Insert query
    $query = "INSERT INTO `teacher_details` (`teacher_id`, `name`, `dob`, `gender`, `join_date`, `qualification`, `address`, `city`, `district`, `state`, `mobile`, `email`) 
              VALUES ('$teacher_id', '$name', '$dob', '$gender', '$join_date', '$qualification', '$address', '$city', '$district', '$state', '$mobile', '$email')";

    $query_run = mysqli_query($conn, $query);

    if ($query_run) {
        $success_msg = "Teacher Details have been submitted successfully!";
        echo ("<SCRIPT LANGUAGE='JavaScript'>
            window.alert('$success_msg');
            window.location.href='show-data.php';
        </SCRIPT>");
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    // Close connection
    mysqli_close($conn);
}
?>
