<?php
if (isset($_POST['submit'])) { // ✅ Removed unnecessary semicolon
    include('../db/connect.php'); // Make sure $conn is defined in connect.php

    // ✅ Secure inputs to prevent SQL Injection
    $teacher_id = mysqli_real_escape_string($conn, $_POST['teacher_id']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $dob = mysqli_real_escape_string($conn, $_POST['dob']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $join_date = mysqli_real_escape_string($conn, $_POST['join_date']);
    $qualification = mysqli_real_escape_string($conn, $_POST['qualification']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    $district = mysqli_real_escape_string($conn, $_POST['district']);
    $state = mysqli_real_escape_string($conn, $_POST['state']);
    $mobile = mysqli_real_escape_string($conn, $_POST['mobile']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    // ✅ Fixed duplicate 'city' field in SQL query
    $query = "UPDATE teacher_details 
              SET name='$name', dob='$dob', gender='$gender', join_date='$join_date', 
                  qualification='$qualification', address='$address', city='$city', 
                  district='$district', state='$state', mobile='$mobile', email='$email'  
              WHERE teacher_id = '$teacher_id'";

    $query_run = mysqli_query($conn, $query); // ✅ Use `mysqli_query()`

    if ($query_run) {
        echo "<script>
                alert('Update has been submitted successfully!');
                window.location.href='show-data.php';
              </script>";
    } else {
        echo "<script>
                alert('Error updating record: " . mysqli_error($conn) . "');
              </script>";
    }
}
?>
