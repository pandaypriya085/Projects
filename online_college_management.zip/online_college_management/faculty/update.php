<?php
include("../db/connect.php");

// ✅ Securely fetch the 'id' parameter
$id = isset($_GET['id']) ? mysqli_real_escape_string($conn, $_GET['id']) : '';

if (!$id) {
    die("Invalid ID");
}

// ✅ Use MySQLi query
$query = mysqli_query($conn, "SELECT * FROM teacher_details WHERE id='$id'");

if (!$query) {
    die("Query Failed: " . mysqli_error($conn));
}

// ✅ Fetch data properly
$data = mysqli_fetch_assoc($query);
if (!$data) {
    die("No record found");
}
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <!-- Meta Tags -->
    <meta name="viewport" content="width=device-width,initial-scale=1.0" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="description" content="Cpathshala " />
    <meta name="keywords" content="academy, course, education, education html theme, elearning, learning," />
    <meta name="author" content="ThemeMascot" />
    <!--Bootsrap 4 CDN-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!--Fontawesome CDN-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <!-- Page Title -->
    <title>Online College Management System</title>
    <!--all css section-->
    <?php include('all-css.php'); ?>
    <!--end all section-->
    <!-- js file external javascripts -->
    <?php include('all-js.php'); ?>
    <!--end all js-->
    <style>
        /* Made with love by Mutiullah Samim*/

        @import url('https://fonts.googleapis.com/css?family=Numans');

        html,
        body {
            background-image: url(path-images/slider.jpg);
            background-size: cover;
            background-repeat: no-repeat;
            height: 100%;
            font-family: 'Numans', sans-serif;
        }

        .container {
            height: 100%;
            align-content: center;
        }

        table tr td {
            color: #000;
        }
    </style>
</head>

<body>
    <div id="wrapper" class="clearfix">
        <?php include('main-menu.php'); ?>

        <div class="main-content">
            <section id="home">
                <div class="container-fluid p-0" style="padding-top:0px; padding-bottom:50px; background:#CCC;">
                    <div class="container">
                        <h3 class="text-center text-black-333">Teacher Details</h3>
                        <form action="update-coding.php" method="post">
                            <table class="table table-bordered">
                                <tr>
                                    <td>Teacher Id No</td>
                                    <td><input type="text" name="teacher_id" value="<?= $data['teacher_id']; ?>" class="form-control" required></td>
                                    <td>Teacher Name</td>
                                    <td><input type="text" name="name" value="<?= $data['name']; ?>" class="form-control" required></td>
                                </tr>
                                <tr>
                                    <td>Date of Birth</td>
                                    <td><input type="date" name="dob" value="<?= $data['dob']; ?>" class="form-control" required></td>
                                    <td>Gender</td>
                                    <td>
                                        <select name="gender" class="form-control">
                                            <option value="male" <?= ($data['gender'] == "male") ? 'selected' : ''; ?>>Male</option>
                                            <option value="female" <?= ($data['gender'] == "female") ? 'selected' : ''; ?>>Female</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Join Date</td>
                                    <td><input type="date" name="join_date" value="<?= $data['join_date']; ?>" class="form-control" required></td>
                                    <td>Qualification</td>
                                    <td><input type="text" name="qualification" value="<?= $data['qualification']; ?>" class="form-control" required></td>
                                </tr>
                                <tr>
                                    <td>Address</td>
                                    <td><input type="text" name="address" value="<?= $data['address']; ?>" class="form-control" required></td>
                                    <td>City</td>
                                    <td><input type="text" name="city" value="<?= $data['city']; ?>" class="form-control" required></td>
                                </tr>
                                <tr>
                                    <td>District</td>
                                    <td><input type="text" name="district" value="<?= $data['district']; ?>" class="form-control" required></td>
                                    <td>State</td>
                                    <td><input type="text" name="state" value="<?= $data['state']; ?>" class="form-control" required></td>
                                </tr>
                                <tr>
                                    <td>Mobile NO</td>
                                    <td><input type="text" name="mobile" value="<?= $data['mobile']; ?>" class="form-control" required></td>
                                    <td>Email Address</td>
                                    <td><input type="email" name="email" value="<?= $data['email']; ?>" class="form-control" required></td>
                                </tr>
                                <tr>
                                    <td colspan="6"><button name="submit" type="submit" class="btn btn-danger">Update</button></td>
                                </tr>
                            </table>
                        </form>
                    </div>
                </div>
            </section>
        </div>
        <?php include('footer.php'); ?>
    </div>
</body>


</html>