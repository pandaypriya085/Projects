<?php
include("../db/connect.php");
$id = $_GET['id'];

// Prepare a SQL query to delete the record
$query = "DELETE FROM fee_collection WHERE id = ?";
$stmt = mysqli_prepare($conn, $query);

// Bind the parameter to the SQL query
mysqli_stmt_bind_param($stmt, "i", $id);

// Execute the query
if (mysqli_stmt_execute($stmt)) {
    $success_msg = "Data Deleted Successfully!";
    echo ("<SCRIPT LANGUAGE='JavaScript'>
            window.alert('$success_msg')
            window.location.href='show-fee.php';
          </SCRIPT>");
} else {
    echo ("<SCRIPT LANGUAGE='JavaScript'>
            window.alert('Error deleting record.')
            window.location.href='show-fee.php';
          </SCRIPT>");
}

// Close the statement and the database connection
mysqli_stmt_close($stmt);
mysqli_close($conn);
?>

