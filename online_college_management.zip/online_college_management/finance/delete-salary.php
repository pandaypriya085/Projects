<?php
include("../db/connect.php");

$id = $_GET['id'];

// Prepare the delete query
$query = "DELETE FROM emp_salary WHERE id = '$id'";

// Execute the query
$query_run = mysqli_query($conn, $query);

// Check if the query was successful
if ($query_run) {
    $success_msg = "Data Deleted Successfully!";
    echo ("<SCRIPT LANGUAGE='JavaScript'>
            window.alert('$success_msg');
            window.location.href='show-salary.php';
          </SCRIPT>");
} else {
    echo "<script>alert('Error: Could not delete the record.');</script>";
}
?>

