<?php
if (isset($_POST['submit'])) {
    include('../db/connect.php'); // Include database connection

    if (!$conn) {
        die("Database connection failed: " . mysqli_connect_error());  // Check for database connection
    }

    // Sanitize and get form inputs
    $bill_no = mysqli_real_escape_string($conn, $_POST['bill_no']);
    $reg_no = mysqli_real_escape_string($conn, $_POST['reg_no']);
    $student_name = mysqli_real_escape_string($conn, $_POST['student_name']);
    $father_name = mysqli_real_escape_string($conn, $_POST['father_name']);
    $year = mysqli_real_escape_string($conn, $_POST['year']);
    $fee_month = mysqli_real_escape_string($conn, $_POST['fee_month']);
    $payment = mysqli_real_escape_string($conn, $_POST['payment']);
    $pay_date = mysqli_real_escape_string($conn, $_POST['pay_date']);

    // SQL query to insert data
    $query = "INSERT INTO `fee_collection`(`bill_no`, `reg_no`, `student_name`, `father_name`, `year`, `fee_month`, `payment`, `pay_date`) 
              VALUES ('$bill_no', '$reg_no', '$student_name', '$father_name', '$year', '$fee_month', '$payment', '$pay_date')";

    // Execute query
    $query_run = mysqli_query($conn, $query); // Use mysqli_query() instead of mysql_query()

    if ($query_run) {
        // Success message
        $success_msg = "Fee has been Submitted Successfully!";
        echo ("<SCRIPT LANGUAGE='JavaScript'>
                window.alert('$success_msg')
                window.location.href='show-fee.php';
                </SCRIPT>");
    } else {
        // Error handling
        echo "Error: " . mysqli_error($conn);
    }

    // Close the database connection
    mysqli_close($conn);
}
?>
