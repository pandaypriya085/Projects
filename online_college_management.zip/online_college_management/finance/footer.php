
  <div class="footer-bottom bg-black-333">
    <div class="container pt-20 pb-20">
      <div class="row">
        <div class="col-md-4">
          <p class="font-11 text-black-777 m-0">Copyright &copy;2025 OCMS. All Rights Reserved</p>
        </div>
        <div class="col-md-4">
          <p class="font-11 text-black-777 m-0">Designed & Developed by <a href="#/" target="_blank">Priya Kumari</a></p>
        </div>
        <div class="col-md-4 text-right">
          <div class="widget no-border m-0">
            <ul class="list-inline sm-text-center mt-5 font-12">
              <li> <a href="#">FAQ</a> </li>
              <li>|</li>
              <li> <a href="#">Help Desk</a> </li>
              <li>|</li>
              <li> <a href="#">Support</a> </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>
<a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper --> 

<!-- Footer Scripts --> 
<!-- JS | Custom script for all pages --> 
<script src="js/custom.js"></script>