<?php
if (isset($_POST['submit'])) {
    include('../db/connect.php');

    // Sanitize inputs to prevent SQL injection
    $bill_no = mysqli_real_escape_string($conn, $_POST['bill_no']);
    $emp_id = mysqli_real_escape_string($conn, $_POST['emp_id']);
    $emp_name = mysqli_real_escape_string($conn, $_POST['emp_name']);
    $salary_month = mysqli_real_escape_string($conn, $_POST['salary_month']);
    $salary = mysqli_real_escape_string($conn, $_POST['salary']);
    $pay_date = mysqli_real_escape_string($conn, $_POST['pay_date']);

    // Prepare the SQL query using prepared statements
    $query = "INSERT INTO `emp_salary`(`bill_no`, `emp_id`, `emp_name`, `salary_month`, `salary`, `pay_date`) 
              VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = mysqli_prepare($conn, $query);

    // Bind parameters to the SQL query
    mysqli_stmt_bind_param($stmt, "ssssds", $bill_no, $emp_id, $emp_name, $salary_month, $salary, $pay_date);

    // Execute the query
    if (mysqli_stmt_execute($stmt)) {
        $success_msg = "Salary has been Submitted Successfully!";
        echo ("<SCRIPT LANGUAGE='JavaScript'>
                window.alert('$success_msg')
                window.location.href='show-salary.php';
              </SCRIPT>");
    } else {
        echo ("<SCRIPT LANGUAGE='JavaScript'>
                window.alert('Error submitting salary details!')
                window.location.href='show-salary.php';
              </SCRIPT>");
    }

    // Close the statement and connection
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
}
?>
