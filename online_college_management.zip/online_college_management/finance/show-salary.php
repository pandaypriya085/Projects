<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
  <!-- Meta Tags -->
  <meta name="viewport" content="width=device-width,initial-scale=1.0" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <meta name="description" content="Cpathshala " />
  <meta name="keywords" content="academy, course, education, education html theme, elearning, learning," />
  <meta name="author" content="ThemeMascot" />
  <!--Bootsrap 4 CDN-->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  <!--Fontawesome CDN-->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
  <!-- Page Title -->
  <title>Online College Management System</title>
  <!--all css section-->
  <?php include('all-css.php'); ?>
  <!--end all section-->
  <!-- js file external javascripts -->
  <?php include('all-js.php'); ?>
  <!--end all js-->
  <style>
    /* Made with love by Mutiullah Samim*/
    @import url('https://fonts.googleapis.com/css?family=Numans');

    html,
    body {
      background-size: cover;
      background-repeat: no-repeat;
      height: 100%;
      font-family: 'Numans', sans-serif;
    }

    .container {
      height: 100%;
      align-content: center;
    }

    table tr td {
      color: #fff;
    }

    table tr th {
      color: #fff;
    }
  </style>
</head>

<body class="">
  <div id="wrapper" class="clearfix">
    <!-- preloader -->
    <div id="preloader">
      <div id="spinner">
        <div class="preloader-dot-loading">
          <div class="cssload-loading"><i></i><i></i><i></i><i></i></div>
        </div>
      </div>
      <div id="disable-preloader" class="btn btn-default btn-sm">Disable Preloader</div>
    </div>

    <!-- Header -->
    <?php include('main-menu.php'); ?>
    <!--end Header-->

    <!-- Start main-content -->
    <div class="main-content">
      <!-- Section: home -->
      <section id="home">
        <div class="container-fluid p-0" style="padding-top:100px; padding-bottom:150px; background:#030;">
          <div class="row">
            <!-- Slider Revolution Start -->
            <div class="container">
              <h3 class="text-center text-gray-lighter"> Show Salary Records </h3>
              <table class="table table-bordered table-responsive" style="width:100%;">
                <thead>
                  <tr>
                    <th>S. No</th>
                    <th>Bill No</th>
                    <th>Employee Id</th>
                    <th>Employee Name</th>
                    <th>Salary of Month</th>
                    <th>Salary</th>
                    <th>Payment Date</th>
                    <th>Delete</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  include("../db/connect.php");
                  $query = "SELECT * FROM emp_salary ORDER BY id DESC";
                  $query_run = mysqli_query($conn, $query);
                  while ($data = mysqli_fetch_array($query_run)) {
                    $id = $data['id'];
                  ?>
                    <tr>
                      <td><?php echo $data['id']; ?></td>
                      <td><?php echo $data['bill_no']; ?></td>
                      <td><?php echo $data['emp_id']; ?></td>
                      <td><?php echo $data['emp_name']; ?></td>
                      <td><?php echo $data['salary_month']; ?></td>
                      <td><?php echo $data['salary']; ?></td>
                      <td><?php echo $data['pay_date']; ?></td>
                      <td><a href="delete-salary.php?id=<?php echo $id; ?>" class="btn btn-danger" onclick="return confirm('Are You Sure To Delete ?')">Delete</a></td>
                    </tr>
                  <?php
                  }
                  ?>

                  </tr>
                </tbody>

              </table>

            </div>
          </div>
      </section>
      <!--courses section-->
      <!-- Footer -->
      <?php include('footer.php'); ?>
      <!--end footer-->
</body>

</html>