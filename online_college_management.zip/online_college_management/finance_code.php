<?php
session_start();
include("db/connect.php"); // Database connection include karein

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!$conn) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    // User input sanitize karein
    $uname = mysqli_real_escape_string($conn, trim($_POST['username']));
    $pword = mysqli_real_escape_string($conn, trim($_POST['password']));

    // Database me user check karne ka secure query
    $query = "SELECT password FROM finance_login WHERE username = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $uname);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        if ($pword === $row['password']) {  // 🔹 Agar password plain text me stored hai
            $_SESSION['username'] = $uname;
            echo "<script>alert('Login Successful.'); window.location.href='finance/index.php';</script>";
            exit;
        } else {
            echo "<script>alert('Wrong username or password entered.');</script>";
        }
    } else {
        echo "<script>alert('No user found.');</script>";
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);
}
?>
