<?php
include("../db/connect.php");
$id = $_GET['id'];

// Use mysqli_query with the correct connection variable
$query = mysqli_query($conn, "DELETE FROM library WHERE id='$id'");

if ($query) {
    $success_msg = "Data Deleted Successfully!";
    echo ("<SCRIPT LANGUAGE='JavaScript'>
            window.alert('$success_msg');
            window.location.href='show-library.php';
          </SCRIPT>");
} else {
    echo ("<SCRIPT LANGUAGE='JavaScript'>
            window.alert('Error Deleting Data!');
          </SCRIPT>");
}
?>

