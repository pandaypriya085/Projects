<?php
if (isset($_POST['submit'])) { // Removed the extra semicolon after the 'if' statement
    include('../db/connect.php');
    $card_no = $_POST['card_no'];
    $reg_no = $_POST['reg_no'];
    $name = $_POST['name'];
    $class = $_POST['class'];
    $roll_no = $_POST['roll_no'];
    $book_title = $_POST['book_title'];
    $issue_date = $_POST['issue_date'];
    $return_date = $_POST['return_date'];
    $no_book = $_POST['no_book'];

    // Prepare the insert query
    $query = "INSERT INTO `library`(`card_no`, `reg_no`, `name`, `class`, `roll_no`, `book_title`, `issue_date`, `return_date`, `no_book`) 
              VALUES ('$card_no', '$reg_no', '$name', '$class', '$roll_no', '$book_title', '$issue_date', '$return_date', '$no_book')";

    // Execute the query
    $query_run = mysqli_query($conn, $query);

    // Check if the query was successful
    if ($query_run) {
        $success_msg = "Library Details have been Submitted Successfully!";
        echo ("<SCRIPT LANGUAGE='JavaScript'>
                window.alert('$success_msg')
                window.location.href='show-library.php';
              </SCRIPT>");
    } else {
        echo "<script>alert('Error: Could not submit the details.');</script>";
    }
}
?>

