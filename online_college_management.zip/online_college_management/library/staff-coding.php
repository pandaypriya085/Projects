<?php
if (isset($_POST['submit'])) { // Remove the extra semicolon
    include('../db/connect.php');
    
    $staff_id = $_POST['staff_id'];
    $name = $_POST['name'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $join_date = $_POST['join_date'];
    $qualification = $_POST['qualification'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $district = $_POST['district'];
    $state = $_POST['state'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $department = $_POST['department'];
    $salary = $_POST['salary'];
    
    $query = "INSERT INTO `staff_details`(`staff_id`,`name`,`dob`, `gender`,`join_date`,`qualification`,`address`,`city`,`district`,`state`,`mobile`,`email`,`department`,`salary`) 
    VALUES ('$staff_id','$name','$dob','$gender','$join_date', '$qualification','$address','$city','$district','$state','$mobile','$email','$department','$salary')";
    
    // Use mysqli_query instead of mysql_query
    $query_run = mysqli_query($conn, $query);

    if ($query_run) {
        $success_msg = "Staff Details have been Submitted Successfully!";
        echo ("<SCRIPT LANGUAGE='JavaScript'>
                window.alert('$success_msg');
                window.location.href='show-staff.php';
                </SCRIPT>");
    }
}
?>
