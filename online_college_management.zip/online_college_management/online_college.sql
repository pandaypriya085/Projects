-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 07, 2023 at 12:38 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 5.6.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_college`
--

-- --------------------------------------------------------

--
-- Table structure for table `admission_details`
--

CREATE TABLE `admission_details` (
  `id` int(10) NOT NULL,
  `reg_no` varchar(100) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `father_name` varchar(100) NOT NULL,
  `occupation` varchar(50) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `nationality` varchar(100) NOT NULL,
  `admission_date` varchar(100) NOT NULL,
  `admission_fee` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `pin_code` varchar(100) NOT NULL,
  `class` varchar(100) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admission_details`
--

INSERT INTO `admission_details` (`id`, `reg_no`, `student_name`, `father_name`, `occupation`, `gender`, `dob`, `nationality`, `admission_date`, `admission_fee`, `city`, `pin_code`, `class`, `mobile`, `address`) VALUES
(11, '12345', 'Rajesh kumar', 'MOHAN KUMAR', 'G.sevice', 'male', '2019-03-27', 'indian', '2019-03-29', '2000', 'Patna', '811308', '11th', '08448446676', '216, 2nd floor,Grand Plaza, Fraser Road');

-- --------------------------------------------------------

--
-- Table structure for table `emp_salary`
--

CREATE TABLE `emp_salary` (
  `id` int(10) NOT NULL,
  `bill_no` varchar(100) NOT NULL,
  `emp_id` varchar(100) NOT NULL,
  `emp_name` varchar(100) NOT NULL,
  `salary_month` varchar(100) NOT NULL,
  `salary` varchar(100) NOT NULL,
  `pay_date` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_salary`
--

INSERT INTO `emp_salary` (`id`, `bill_no`, `emp_id`, `emp_name`, `salary_month`, `salary`, `pay_date`) VALUES
(4, '130', '1251', 'MOHAM KUMAR', 'March', '50000', '2019-02-27'),
(3, '125', '1250', 'MOHAM KUMAR', 'August', '50000', '2019-02-20');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_login`
--

CREATE TABLE `faculty_login` (
  `id` int(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty_login`
--

INSERT INTO `faculty_login` (`id`, `username`, `password`) VALUES
(2, 'faculty', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `fee_collection`
--

CREATE TABLE `fee_collection` (
  `id` int(10) NOT NULL,
  `bill_no` varchar(100) NOT NULL,
  `reg_no` varchar(100) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `father_name` varchar(100) NOT NULL,
  `year` varchar(100) NOT NULL,
  `fee_month` varchar(100) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `pay_date` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fee_collection`
--

INSERT INTO `fee_collection` (`id`, `bill_no`, `reg_no`, `student_name`, `father_name`, `year`, `fee_month`, `payment`, `pay_date`) VALUES
(4, '125', '123452', 'MD SANJAR HUSSAIN', 'HUSSAIN', '2nd-yaer', 'February', '5000', '2019-02-13'),
(5, '130', '123456', 'Manoj', 'MOHAN KUMAR', '2nd-yaer', 'September', '12500', '2019-02-20'),
(13, '130', '12345', 'Rajesh kumar', 'RAJESH KUMAR SINGH', '1st_year', 'August', '5000', '2019-02-21');

-- --------------------------------------------------------

--
-- Table structure for table `finance_login`
--

CREATE TABLE `finance_login` (
  `id` int(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `finance_login`
--

INSERT INTO `finance_login` (`id`, `username`, `password`) VALUES
(2, 'finance', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `library`
--

CREATE TABLE `library` (
  `id` int(10) NOT NULL,
  `card_no` varchar(100) NOT NULL,
  `reg_no` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `class` varchar(100) NOT NULL,
  `roll_no` varchar(100) NOT NULL,
  `book_title` varchar(100) NOT NULL,
  `issue_date` varchar(100) NOT NULL,
  `return_date` varchar(100) NOT NULL,
  `no_book` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `library`
--

INSERT INTO `library` (`id`, `card_no`, `reg_no`, `name`, `class`, `roll_no`, `book_title`, `issue_date`, `return_date`, `no_book`) VALUES
(5, '1234', '1234', 'Md Asif', '12', '12', 'Welcome', '2023-04-06', '2023-04-21', '5'),
(6, '1234', '1234', 'Md Asif', '12', '12', 'Welcome', '2023-04-22', '2023-04-28', '5');

-- --------------------------------------------------------

--
-- Table structure for table `library_login`
--

CREATE TABLE `library_login` (
  `id` int(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `library_login`
--

INSERT INTO `library_login` (`id`, `username`, `password`) VALUES
(2, 'library', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`) VALUES
(1, 'admin', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `staff_details`
--

CREATE TABLE `staff_details` (
  `id` int(10) NOT NULL,
  `staff_id` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `join_date` varchar(100) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `salary` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff_details`
--

INSERT INTO `staff_details` (`id`, `staff_id`, `name`, `dob`, `gender`, `join_date`, `qualification`, `address`, `city`, `district`, `state`, `mobile`, `email`, `department`, `salary`) VALUES
(6, '140', 'Mohan kumar', '2019-03-13', 'male', '2019-02-15', 'mca', '216, 2nd floor,Grand Plaza, Fraser Road, Dak Bunglow, Patna-1', 'Patna', '2019-02-15', 'bihar', '180030026167', 'hussain704@gmail.com', 'Computer science', '25000');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_details`
--

CREATE TABLE `teacher_details` (
  `id` int(10) NOT NULL,
  `teacher_id` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `join_date` varchar(100) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher_details`
--

INSERT INTO `teacher_details` (`id`, `teacher_id`, `name`, `dob`, `gender`, `join_date`, `qualification`, `address`, `city`, `district`, `state`, `mobile`, `email`) VALUES
(14, '12345', 'Md Asif', '2023-04-08', 'male', '2023-04-07', '12', 'NEw Delhi', 'patna', 'Patna', 'bihar', '9304673653', 'mdasif9a@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admission_details`
--
ALTER TABLE `admission_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emp_salary`
--
ALTER TABLE `emp_salary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faculty_login`
--
ALTER TABLE `faculty_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fee_collection`
--
ALTER TABLE `fee_collection`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `finance_login`
--
ALTER TABLE `finance_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `library`
--
ALTER TABLE `library`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `library_login`
--
ALTER TABLE `library_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff_details`
--
ALTER TABLE `staff_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher_details`
--
ALTER TABLE `teacher_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admission_details`
--
ALTER TABLE `admission_details`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `emp_salary`
--
ALTER TABLE `emp_salary`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `faculty_login`
--
ALTER TABLE `faculty_login`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fee_collection`
--
ALTER TABLE `fee_collection`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `finance_login`
--
ALTER TABLE `finance_login`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `library`
--
ALTER TABLE `library`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `library_login`
--
ALTER TABLE `library_login`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `staff_details`
--
ALTER TABLE `staff_details`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `teacher_details`
--
ALTER TABLE `teacher_details`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
