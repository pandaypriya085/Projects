<?php
if (isset($_POST['submit'])) {
    include('../db/connect.php'); // Ensure this file has MySQLi connection ($conn)

    // Get form data
    $reg_no = $_POST['reg_no'];
    $student_name = $_POST['student_name'];
    $father_name = $_POST['father_name'];
    $occupation = $_POST['occupation'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $nationality = $_POST['nationality'];
    $admission_date = $_POST['admission_date'];
    $admission_fee = $_POST['admission_fee'];
    $city = $_POST['city'];
    $pin_code = $_POST['pin_code'];
    $class = $_POST['class'];
    $mobile = $_POST['mobile'];
    $address = $_POST['address'];

    // Use prepared statements for security
    $query = "INSERT INTO admission_details (reg_no, student_name, father_name, occupation, gender, dob, nationality, admission_date, admission_fee, city, pin_code, class, mobile, address) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ssssssssssssss", $reg_no, $student_name, $father_name, $occupation, $gender, $dob, $nationality, $admission_date, $admission_fee, $city, $pin_code, $class, $mobile, $address);

    if (mysqli_stmt_execute($stmt)) {
        echo ("<script>
                alert('Data has been Submitted Successfully!');
                window.location.href='index.php';
               </script>");
    } else {
        echo ("<script>
                alert('Error submitting data: " . mysqli_error($conn) . "');
               </script>");
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);
}
?>
