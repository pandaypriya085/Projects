<?php
include("../db/connect.php"); // Database connection include karein

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // ID ko integer me convert karein

    // Check if ID exists before deleting
    $check_id = "SELECT * FROM admission_details WHERE id = '$id'";
    $result = mysqli_query($conn, $check_id);

    if (mysqli_num_rows($result) > 0) {
        // Delete query
        $query = "DELETE FROM admission_details WHERE id = '$id'";
        $query_run = mysqli_query($conn, $query); // ✅ Corrected!

        if ($query_run) {
            echo "<script>
                    alert('Record deleted successfully!');
                    window.location.href='show-record.php';
                  </script>";
        } else {
            echo "Error deleting record: " . mysqli_error($conn);
        }
    } else {
        echo "Error: No record found with ID = $id";
    }
} else {
    echo "Error: ID parameter is missing!";
}

// Close connection
mysqli_close($conn);
?>

