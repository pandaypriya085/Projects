<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="Cpathshala " />
<meta name="keywords" content="academy, course, education, education html theme, elearning, learning," />
<meta name="author" content="ThemeMascot" />
	<!--Bootsrap 4 CDN-->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!--Fontawesome CDN-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
<!-- Page Title -->
<title>Online College Management System</title>
<!--all css section-->
<?php include('all-css.php'); ?>
<!--end all section-->
<!-- js file external javascripts -->
<?php include('all-js.php');?>
<!--end all js-->
<style>
/* Made with love by Mutiullah Samim*/
@import url('https://fonts.googleapis.com/css?family=Numans');
html,body{
background-image: url(path-images/slider.jpg);
background-size: cover;
background-repeat: no-repeat;
height:100%;
font-family: 'Numans', sans-serif;
}
.container{
height: 100%;
align-content: center;
}
table tr td{
	color:#000;
}
</style>
</head>
<body class="">
<div id="wrapper" class="clearfix"> 
  <!-- preloader -->
  <div id="preloader">
    <div id="spinner">
      <div class="preloader-dot-loading">
        <div class="cssload-loading"><i></i><i></i><i></i><i></i></div>
      </div>
    </div>
    <div id="disable-preloader" class="btn btn-default btn-sm">Disable Preloader</div>
  </div>
  
  <!-- Header -->
  <?php include('main-menu.php'); ?>
  <!--end Header-->

<!-- Start main-content -->
<div class="main-content"> 
  <!-- Section: home -->
  <section id="home">
    <div class="container-fluid p-0"  style="padding-top:0px; padding-bottom:50px; background-color: #CCC">
      <div class="row"> 
        <!-- Slider Revolution Start -->
     <div class="container">
     <h3 class="text-center text-black-333"> New Student Admission Details</h3>
     <form action="admission_coding.php" method="post">
	<table class="table table-bordered">
    <tr>
    <td>Registration No</td>
    <td><input type="text" name="reg_no" class="form-control" required></td>
    <td>Student Name</td>
    <td><input type="text" name="student_name" class="form-control" required></td>
    <td>Father Name</td>
    <td><input type="text"  name="father_name" class="form-control" required></td>
    </tr>
    
    <tr>
      <td>Occupation</td>
    <td><input type="text"  name="occupation" class="form-control" required></td>
      <td>Gender</td>
    <td><select  name="gender" class="form-control">
    <option value="0">Select cagetory</option>
<option value="male">Male</option>
<option value="female">Female</option>
</select>
    </td>
      <td>Date of Birth</td>
    <td><input type="date" name="dob" class="form-control" required></td>
    </tr>
    
     <tr>
      <td>Nationality</td>
    <td><input type="text"  name="nationality" class="form-control" required></td>
      <td>Admission Date</td>
    <td><input type="date"  name="admission_date" class="form-control" required></td>
      <td>Admission Fee</td>
    <td><input type="text"  name="admission_fee" class="form-control" required></td>
    </tr>
    
     <tr>
      <td>City</td>
    <td><input type="text" name="city" class="form-control" required></td>
      <td>Pin Code</td>
    <td><input type="text" name="pin_code" class="form-control" required></td>
      <td>Class</td>
    <td><input type="text" name="class" class="form-control" required></td>
    </tr>
    
    <tr>
      <td>Mobile No</td>
    <td><input type="text" name="mobile" class="form-control" required></td>
      <td>address</td>
    <td class="3"><input type="text"  name="address" class="form-control" required></td>
    </tr>
    <tr>
    <td colspan="6"><button name="submit" type="submit" value="submit"  class="btn btn-danger">Submit</button>&nbsp;&nbsp;<button name="clear" type="clear" value="clear"  class="btn btn-danger">Clear</button></td>
    </tr>
    </table>
    </form>
    
</div>
    </div>
  </section>
  <!--courses section-->
 <!-- Footer -->
<?php include ('footer.php');?>
<!--end footer-->
</body>
</html>