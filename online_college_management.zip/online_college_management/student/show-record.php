<?php
include("../db/connect.php"); // Ensure this file has MySQLi connection ($conn)

$query = "SELECT * FROM admission_details ORDER BY id DESC";
$query_run = mysqli_query($conn, $query);

// 🔹 Add Debugging Check
if (!$query_run) {
    die("Query Failed: " . mysqli_error($conn)); // Shows the exact error
}
?>


<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
  <!-- Meta Tags -->
  <meta name="viewport" content="width=device-width,initial-scale=1.0" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <meta name="description" content="Cpathshala " />
  <meta name="keywords" content="academy, course, education, education html theme, elearning, learning," />
  <meta name="author" content="ThemeMascot" />
  <!--Bootsrap 4 CDN-->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  <!--Fontawesome CDN-->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
  <!-- Page Title -->
  <title>Online College Management System</title>
  <!--all css section-->
  <?php include('all-css.php'); ?>
  <!--end all section-->
  <!-- js file external javascripts -->
  <?php include('all-js.php'); ?>
  <!--end all js-->
  <style>
    /* Made with love by Mutiullah Samim*/
    @import url('https://fonts.googleapis.com/css?family=Numans');

    html,
    body {
      background-image: url(path-images/slider.jpg);
      background-size: cover;
      background-repeat: no-repeat;
      height: 100%;
      font-family: 'Numans', sans-serif;
    }

    .container {
      height: 100%;
      align-content: center;
    }

    table tr td {
      color: #000;
    }
  </style>
</head>

<body>
  <div id="wrapper" class="clearfix">
    <?php include('main-menu.php'); ?>

    <div class="main-content">
      <section id="home">
        <div class="container-fluid p-0" style="padding-bottom:50px; background:#CCC">
          <div class="container">
            <h3 class="text-center text-black-333">Show Student Records</h3>
            <table class="table table-bordered table-responsive">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Reg No.</th>
                  <th>S. Name</th>
                  <th>F. Name</th>
                  <th>Occupation</th>
                  <th>Gender</th>
                  <th>DOB</th>
                  <th>Nationality</th>
                  <th>Admission Date</th>
                  <th>Admission Fee</th>
                  <th>City</th>
                  <th>Pin Code</th>
                  <th>Class</th>
                  <th>Mobile No</th>
                  <th>Address</th>
                  <th>Update</th>
                  <th>Delete</th>
                </tr>
              </thead>
              <tbody>
                <?php while ($data = mysqli_fetch_assoc($query_run)) { ?>
                  <tr>
                    <td><?= $data['id']; ?></td>
                    <td><?= $data['reg_no']; ?></td>
                    <td><?= $data['student_name']; ?></td>
                    <td><?= $data['father_name']; ?></td>
                    <td><?= $data['occupation']; ?></td>
                    <td><?= $data['gender']; ?></td>
                    <td><?= $data['dob']; ?></td>
                    <td><?= $data['nationality']; ?></td>
                    <td><?= $data['admission_date']; ?></td>
                    <td><?= $data['admission_fee']; ?></td>
                    <td><?= $data['city']; ?></td>
                    <td><?= $data['pin_code']; ?></td>
                    <td><?= $data['class']; ?></td>
                    <td><?= $data['mobile']; ?></td>
                    <td><?= $data['address']; ?></td>
                    <td><a href="update-record.php?id=<?= $data['id']; ?>" class="btn btn-warning">Update</a></td>
                    <td><a href="delete-record.php?id=<?= $data['id']; ?>" class="btn btn-danger" onclick="return confirm('Are You Sure To Delete ?')">Delete</a></td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <?php include('footer.php'); ?>
    </div>
  </div>
</body>

</html>