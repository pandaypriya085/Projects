<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') { // Ensure form is submitted
    include('../db/connect.php');

    if (!$conn) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    // Sanitize inputs
    $id = isset($_POST['id']) ? mysqli_real_escape_string($conn, $_POST['id']) : '';
    
    if (empty($id)) {
        die("Error: ID is missing. Cannot update record.");
    }

    $reg_no = mysqli_real_escape_string($conn, $_POST['reg_no']);
    $student_name = mysqli_real_escape_string($conn, $_POST['student_name']);
    $father_name = mysqli_real_escape_string($conn, $_POST['father_name']);
    $occupation = mysqli_real_escape_string($conn, $_POST['occupation']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $dob = mysqli_real_escape_string($conn, $_POST['dob']);
    $nationality = mysqli_real_escape_string($conn, $_POST['nationality']);
    $admission_date = mysqli_real_escape_string($conn, $_POST['admission_date']);
    $admission_fee = mysqli_real_escape_string($conn, $_POST['admission_fee']);
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    $pin_code = mysqli_real_escape_string($conn, $_POST['pin_code']);
    $class = mysqli_real_escape_string($conn, $_POST['class']);
    $mobile = mysqli_real_escape_string($conn, $_POST['mobile']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);

    // Debugging: Check POST data
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";

    // Check if ID exists before updating
    $check_id = "SELECT * FROM admission_details WHERE id = '$id'";
    $result = mysqli_query($conn, $check_id);

    if ($result && mysqli_num_rows($result) > 0) {
        // Update query
        $query = "UPDATE admission_details 
                  SET reg_no='$reg_no', student_name='$student_name', father_name='$father_name', 
                      occupation='$occupation', gender='$gender', dob='$dob', nationality='$nationality', 
                      admission_date='$admission_date', admission_fee='$admission_fee', city='$city',  
                      pin_code='$pin_code', class='$class', mobile='$mobile', address='$address' 
                  WHERE id = '$id'";

        if (mysqli_query($conn, $query)) {
            echo "<script>
                    alert('Update successful!');
                    window.location.href='show-record.php';
                  </script>";
        } else {
            echo "Error updating record: " . mysqli_error($conn);
        }
    } else {
        echo "Error: No record found with ID = $id";
    }

    // Close connection
    mysqli_close($conn);
}
?>

