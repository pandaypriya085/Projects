<?php
include("../db/connect.php"); // Ensure this file has a proper MySQLi connection

// Check if ID is provided
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Sanitize input

    // Use MySQLi query
    $query = "SELECT * FROM admission_details WHERE id = $id";
    $query_run = mysqli_query($conn, $query);

    if ($query_run && mysqli_num_rows($query_run) > 0) {
        $data = mysqli_fetch_assoc($query_run);
    } else {
        die("No record found!");
    }
} else {
    die("ID not provided!");
}
?>
  <!DOCTYPE html>
  <html dir="ltr" lang="en">

  <head>
    <!-- Meta Tags -->
    <meta name="viewport" content="width=device-width,initial-scale=1.0" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="description" content="Cpathshala " />
    <meta name="keywords" content="academy, course, education, education html theme, elearning, learning," />
    <meta name="author" content="ThemeMascot" />
    <!--Bootsrap 4 CDN-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!--Fontawesome CDN-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <!-- Page Title -->
    <title>Online College Management System</title>
    <!--all css section-->
    <?php include('all-css.php'); ?>
    <!--end all section-->
    <!-- js file external javascripts -->
    <?php include('all-js.php'); ?>
    <!--end all js-->
    <style>
      /* Made with love by Mutiullah Samim*/
      @import url('https://fonts.googleapis.com/css?family=Numans');

      html,
      body {
        background-image: url(path-images/slider.jpg);
        background-size: cover;
        background-repeat: no-repeat;
        height: 100%;
        font-family: 'Numans', sans-serif;
      }

      .container {
        height: 100%;
        align-content: center;
      }

      table tr td {
        color: #000;
      }
    </style>
  </head>

  <body class="">
    <div id="wrapper" class="clearfix">
      <!-- preloader -->
      <div id="preloader">
        <div id="spinner">
          <div class="preloader-dot-loading">
            <div class="cssload-loading"><i></i><i></i><i></i><i></i></div>
          </div>
        </div>
        <div id="disable-preloader" class="btn btn-default btn-sm">Disable Preloader</div>
      </div>

      <!-- Header -->
      <?php include('main-menu.php'); ?>
      <!--end Header-->

      <!-- Start main-content -->
      <div class="main-content">
        <!-- Section: home -->
        <section id="home">
          <div class="container-fluid p-0" style="padding-top:0px; padding-bottom:50px; background:#CCC">
            <div class="row">
              <!-- Slider Revolution Start -->
              <div class="container">
                <h3 class="text-center text-black-333"> New Student Admission Details</h3>
                <form action="update-coding.php" method="post">
                  <table class="table table-bordered">
                    <tr>
                      <td>Id</td>
                      <td><input type="text" name="id" class="form-control" value="<?php echo $data['id']; ?>" required raedonly></td>
                      </td>
                    </tr>
                    <tr>
                      <td>Registration No</td>
                      <td><input type="text" name="reg_no" class="form-control" value="<?php echo $data['reg_no']; ?>" required></td>
                      <td>Student Name</td>
                      <td><input type="text" name="student_name" class="form-control" value="<?php echo $data['student_name']; ?>" required></td>
                      <td>Father Name</td>
                      <td><input type="text" name="father_name" class="form-control" value="<?php echo $data['father_name']; ?>" required></td>
                    </tr>

                    <tr>
                      <td>Occupation</td>
                      <td><input type="text" name="occupation" class="form-control" value="<?php echo $data['occupation']; ?>" required></td>
                      <td>Gender</td>
                      <td><select name="gender" class="form-control">
                          <option value="0">Select cagetory</option>
                          <?php
                          if ($data['gender'] == "male") {
                            echo "<option value='male' selected>Male</option>";
                            echo "<option value='female'>Female</option>";
                          } elseif ($data['gender'] == "female") {
                            echo "<option value='male'>Male</option>";
                            echo "<option value='female' selected>Female</option>";
                          } else {
                            echo "<option value='male'>Male</option>";
                            echo "<option value='female'>Female</option>";
                          }
                          ?>
                        </select>
                      </td>
                      <td>Date of Birth</td>
                      <td><input type="date" name="dob" class="form-control" required></td>
                    </tr>

                    <tr>
                      <td>Nationality</td>
                      <td><input type="text" name="nationality" class="form-control" value="<?php echo $data['nationality']; ?>" required></td>
                      <td>Admission Date</td>
                      <td><input type="date" name="admission_date" class="form-control" value="<?php echo $data['admission_date']; ?>" required></td>
                      <td>Admission Fee</td>
                      <td><input type="text" name="admission_fee" class="form-control" value="<?php echo $data['admission_fee']; ?>" required></td>
                    </tr>

                    <tr>
                      <td>City</td>
                      <td><input type="text" name="city" class="form-control" value="<?php echo $data['city']; ?>" required></td>
                      <td>Pin Code</td>
                      <td><input type="text" name="pin_code" class="form-control" value="<?php echo $data['pin_code']; ?>" required></td>
                      <td>Class</td>
                      <td><input type="text" name="class" class="form-control" value="<?php echo $data['class']; ?>" required></td>
                    </tr>

                    <tr>
                      <td>Mobile No</td>
                      <td><input type="text" name="mobile" class="form-control" value="<?php echo $data['mobile']; ?>" required></td>
                      <td>address</td>
                      <td class="3"><input type="text" name="address" class="form-control" value="<?php echo $data['address']; ?>" required></td>
                    </tr>
                    <tr>
                      <td colspan="6"><button name="update" type="submit" value="update" class="btn btn-danger">update</button>&nbsp;&nbsp;</td>
                    </tr>
                  </table>
                </form>


              </div>
            </div>
        </section>
      </div>
    <?php

    ?>
    <!--courses section-->
    <!-- Footer -->
    <?php include('footer.php'); ?>
    <!--end footer-->
  </body>

  </html>